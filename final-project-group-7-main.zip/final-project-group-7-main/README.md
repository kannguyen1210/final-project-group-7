# final-project-group-7

For our final project, we are looking at police brutality.
Present-day conflicts of equality vs. equity
We decided to relate the difference between equity and equality using data on police violence against minorities
We will use machine learning to see if it can predict the race of an individual killed by police using multiple variables such as: if armed, fleeing from police, age, 
We want to see if the individuals killed by police were indeed a threat, or were the killings race driven.


A Logistic Regression model was used to predict if the individuals were African American or not.

In the first portion we want to see if the individuals killed by police were indeed a threat, or race driven

In the second portion of the project we want to explore conceptual similarities scores across relevant words we have chosen using Natural Language Processing (NLP), heavily drawing from machine learning and AI models GloVe (GLobal Vectors for Word Representation) and spaCy

Dashboard: Our plans for the dashboard revolves around an interactive Tableau page...
